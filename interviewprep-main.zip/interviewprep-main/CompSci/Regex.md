# Replacing Whitespace

```java
"string".replaceAll("\\s", "")
```