# Java Basics
Reminders because my Java is rusty.

### Array Syntax

```java
// Basic array
int[] array = { 2, 3, 6, 9 };

// 2D Array
int[][] array = {
					{ 2, 3, 6, 9 },
					{ 2, 3, 6, 9 }
				};
				
int[][] array = new int[10][20];
```

# Helpers

`Character.isLetterOrDigit('x')`