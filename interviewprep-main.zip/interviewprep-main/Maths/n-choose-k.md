# n-choose-k Problems

${\displaystyle {\binom {n}{k}}={\frac {n!}{k!(n-k)!}}.}$